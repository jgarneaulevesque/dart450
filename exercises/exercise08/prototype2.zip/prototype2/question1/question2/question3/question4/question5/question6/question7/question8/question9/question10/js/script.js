/**********************************************

DART 450, Winter 2018
Title of Project
Author

Description of what the script does...

**********************************************/

$(document).ready(function () {

  // Insert jQuery code here to run when the page is loaded

  var delay=1000;
  setTimeout(function(){
    responsiveVoice.speak("We made it!", "US English Female", {pitch: 1.4, rate: 0.7, volume:13});
},delay);

  var delay= 3000;
  setTimeout(function(){
    responsiveVoice.speak("We finally passed to the last barrier of this game. Therefore, I can collect my original data from the file of the game.", "US English Female", {pitch: 1.4, volume:13});
},delay);

var delay= 11000;
setTimeout(function(){
  responsiveVoice.speak("Thank you so much for your help! I will remember your kindness act forever! I will return to my game now. I hope to see you soon. Farewell!  ", "US English Female", {pitch: 1.5, rate: 0.9, volume:13});
},delay);

});
