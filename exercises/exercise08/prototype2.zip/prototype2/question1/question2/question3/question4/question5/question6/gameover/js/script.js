/**********************************************

DART 450, Winter 2018
Title of Project
Author

Description of what the script does...

**********************************************/

$(document).ready(function () {

  // Insert jQuery code here to run when the page is loaded


document.getElementById("scream").autoplay;

var delay=4000;
setTimeout(function(){
responsiveVoice.speak("Good job! you fail miserably on the first question. What a looser… Are you really worthy to save her?", "UK English Male", {pitch: 0.1, rate:0.7,
  volume: 1});
},delay);


//var delay=4000;
//setTimeout(function(){
  //responsiveVoice.speak("What have you done? ", "US English Female", {pitch: 0.9, rate: 0.3,
  //volume: 1});
//},delay);


//var delay=4000;
//setTimeout(function(){
  //responsiveVoice.speak("I can't move...", "US English Female", {pitch: 0.5, rate: 0.2,
  //volume: 1});
//},delay);

//var delay=4000;
//setTimeout(function(){
  //responsiveVoice.speak("It's feel cold...", "US English Female", {pitch: 0.2, rate: 0.1,
  //volume: 1});
//},delay);


//var delay=4000;
//setTimeout(function(){
  //responsiveVoice.speak("cold... and dark...", "US English Female", {pitch: 0.1, rate: 0.1,
  //volume: 1});
//},delay);

//var delay=4000;
//setTimeout(function(){
  //responsiveVoice.speak("Good, bye", "US English Female", {pitch: -0.1, rate: 0.1,
  //volume: 1});
//},delay);


});
