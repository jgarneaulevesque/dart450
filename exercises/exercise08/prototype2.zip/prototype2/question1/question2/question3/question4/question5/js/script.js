/**********************************************

DART 450, Winter 2018
Title of Project
Author

Description of what the script does...

**********************************************/

$(document).ready(function () {

  // Insert jQuery code here to run when the page is loaded
    responsiveVoice.speak("If you want to help me to get out of this game, we must hack the game by going through the security barriers that the programmer scripted to prevent me from leaving. Each security barriers have a riddle to answers. If you answered correctly, we will move forward to the next barrier and to be able to finally get me free. However if you made a single mistake on an answer, the game will crash and thereby this will erase my data. Which I will disappear forever. Are you always ready to help me? ", "US English Female", {pitch: 1.2, rate: 0.8, volume:1});

});
