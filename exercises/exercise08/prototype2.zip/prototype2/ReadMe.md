## Notice from the creator

For a better experience, view the game through the Google Chrome browser
